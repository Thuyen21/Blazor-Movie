﻿namespace BlazorApp3.Shared
{
    internal class DisableFormValueModelBindingAttribute
    {
    }
}
