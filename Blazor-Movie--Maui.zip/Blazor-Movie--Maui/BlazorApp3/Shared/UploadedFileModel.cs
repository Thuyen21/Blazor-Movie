﻿namespace BlazorApp3.Shared
{
    public class UploadedFileModel
    {
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
    }
}
