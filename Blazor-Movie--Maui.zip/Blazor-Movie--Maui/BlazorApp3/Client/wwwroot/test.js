
function myFunction() {
    document.getElementById('id01').style.display = 'none';
}

function myFunction2() {
    document.getElementById('id01').style.display = 'block';
}