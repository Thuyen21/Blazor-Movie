﻿using Foundation;
using Microsoft.Maui;

namespace MauiApp1
{
	[Register("AppDelegate")]
	public class AppDelegate : MauiUIApplicationDelegate<Startup>
	{
	}
}